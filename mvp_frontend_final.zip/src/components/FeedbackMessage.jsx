import React from 'react';

const FeedbackMessage = ({ mensagem }) => (
  <p style={{ color: 'green', fontWeight: 'bold' }}>{mensagem}</p>
);

export default FeedbackMessage;
