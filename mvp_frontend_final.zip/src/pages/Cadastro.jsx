import React, { useState, useEffect } from 'react';
import FeedbackMessage from '../components/FeedbackMessage';

const Cadastro = () => {
  const [titulo, setTitulo] = useState('');
  const [autor, setAutor] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [livros, setLivros] = useState([]);

  useEffect(() => {
    const salvos = JSON.parse(localStorage.getItem('livrosFavoritos')) || [];
    setLivros(salvos);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!titulo || !autor) {
      setMensagem('Preencha todos os campos.');
      return;
    }
    const novo = { titulo, autor };
    const atualizados = [...livros, novo];
    localStorage.setItem('livrosFavoritos', JSON.stringify(atualizados));
    setLivros(atualizados);
    setTitulo('');
    setAutor('');
    setMensagem('Livro cadastrado com sucesso!');
  };

  return (
    <main>
      <h2>Cadastrar Livro</h2>
      <form onSubmit={handleSubmit}>
        <input value={titulo} onChange={(e) => setTitulo(e.target.value)} placeholder="Título" />
        <input value={autor} onChange={(e) => setAutor(e.target.value)} placeholder="Autor" />
        <button type="submit">Salvar</button>
      </form>
      {mensagem && <FeedbackMessage mensagem={mensagem} />}
      <h3>Livros Favoritos</h3>
      <ul>
        {livros.map((livro, idx) => (
          <li key={idx}>{livro.titulo} - {livro.autor}</li>
        ))}
      </ul>
    </main>
  );
};

export default Cadastro;
