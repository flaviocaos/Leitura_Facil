import React from 'react';

const NotFound = () => (
  <main>
    <h2>404 - Página não encontrada</h2>
    <p>Verifique a URL digitada.</p>
  </main>
);

export default NotFound;
