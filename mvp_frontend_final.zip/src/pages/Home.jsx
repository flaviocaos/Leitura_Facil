import React from 'react';

const Home = () => (
  <main>
    <h2>Bem-vindo ao Sistema de Livros</h2>
    <p>Use a barra de navegação para buscar ou cadastrar livros.</p>
  </main>
);

export default Home;
