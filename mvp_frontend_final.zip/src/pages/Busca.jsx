import React, { useState } from 'react';
import axios from 'axios';
import BookCard from '../components/BookCard';

const Busca = () => {
  const [termo, setTermo] = useState('');
  const [resultados, setResultados] = useState([]);
  const [erro, setErro] = useState('');

  const buscarLivros = async () => {
    try {
      const res = await axios.get(\`https://www.googleapis.com/books/v1/volumes?q=\${termo}\`);
      setResultados(res.data.items || []);
      setErro('');
    } catch (error) {
      setErro('Erro ao buscar livros.');
      setResultados([]);
    }
  };

  return (
    <main>
      <h2>Buscar Livros</h2>
      <input value={termo} onChange={(e) => setTermo(e.target.value)} placeholder="Digite o título" />
      <button onClick={buscarLivros}>Buscar</button>
      {erro && <p style={{ color: 'red' }}>{erro}</p>}
      <div>
        {resultados.map((item) => (
          <BookCard key={item.id} livro={item.volumeInfo} />
        ))}
      </div>
    </main>
  );
};

export default Busca;
